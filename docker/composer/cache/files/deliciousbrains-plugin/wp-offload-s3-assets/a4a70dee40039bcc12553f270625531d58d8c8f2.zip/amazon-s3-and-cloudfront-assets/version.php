<?php
$GLOBALS['aws_meta']['amazon-s3-and-cloudfront-assets']['version'] = '1.2.7';
