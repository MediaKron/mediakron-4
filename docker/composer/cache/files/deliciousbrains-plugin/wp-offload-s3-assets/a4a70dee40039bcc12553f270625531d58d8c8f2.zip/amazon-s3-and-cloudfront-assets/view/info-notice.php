<div class="as3cf-notice inline subtle">
	<p class="dashicons-before dashicons-info">
		<?php echo $message; ?>
	</p>
</div>