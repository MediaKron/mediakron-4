<?php

namespace DeliciousBrains\WP_Offload_S3_Assets_Pull\Exceptions;

class Invalid_Response_Type_Exception extends Domain_Check_Exception {

}