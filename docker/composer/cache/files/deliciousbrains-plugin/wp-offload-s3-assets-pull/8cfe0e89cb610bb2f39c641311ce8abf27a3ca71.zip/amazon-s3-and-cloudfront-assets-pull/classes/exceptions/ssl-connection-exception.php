<?php

namespace DeliciousBrains\WP_Offload_S3_Assets_Pull\Exceptions;

class Ssl_Connection_Exception extends Domain_Check_Exception {

}