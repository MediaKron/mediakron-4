<?php
$GLOBALS['aws_meta']['amazon-s3-and-cloudfront-assets-pull']['version'] = '1.0.1';
