<?php

namespace DeliciousBrains\WP_Offload_S3_Assets_Pull\Exceptions;

class Malformed_Query_String_Exception extends Domain_Check_Exception {

}