<?php

namespace DeliciousBrains\WP_Offload_S3\Upgrades\Exceptions;

class No_More_Blogs_Exception extends \Exception {

}